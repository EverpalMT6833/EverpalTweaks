#!/system/bin/sh

set -e

DEBUG=false

MODDIR=${0%/*}

exit 0
